--
-- PostgreSQL database dump
--

\restrict oqHpw6RPnmb0bGwOJfYockcnouBd6OXAJk9QAkq8mhWULQKFhqf0ov7ETmiY4ta

-- Dumped from database version 17.9 (Ubuntu 17.9-1.pgdg24.04+1)
-- Dumped by pg_dump version 17.9 (Ubuntu 17.9-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Account" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    action text NOT NULL,
    ip text,
    "userId" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: LoginChallenge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."LoginChallenge" (
    id text NOT NULL,
    "userId" text NOT NULL,
    mode text NOT NULL,
    "codeHash" text NOT NULL,
    "codeExpiresAt" timestamp(3) without time zone NOT NULL,
    "codeAttempts" integer DEFAULT 0 NOT NULL,
    "verifiedAt" timestamp(3) without time zone,
    "loginTokenHash" text,
    "loginTokenExpiresAt" timestamp(3) without time zone,
    "loginTokenUsedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: PasswordResetChallenge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PasswordResetChallenge" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "emailCodeHash" text NOT NULL,
    "emailCodeVerifiedAt" timestamp(3) without time zone,
    "emailCodeExpiresAt" timestamp(3) without time zone NOT NULL,
    "emailCodeAttempts" integer DEFAULT 0 NOT NULL,
    "smsCodeHash" text,
    "smsCodeVerifiedAt" timestamp(3) without time zone,
    "smsCodeExpiresAt" timestamp(3) without time zone,
    "smsCodeAttempts" integer DEFAULT 0 NOT NULL,
    "resetTokenHash" text,
    "resetTokenExpiresAt" timestamp(3) without time zone,
    "resetTokenUsedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: PasswordResetToken; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PasswordResetToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: RateLimitAttempt; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RateLimitAttempt" (
    id text NOT NULL,
    key text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "sessionToken" text NOT NULL,
    "userId" text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text,
    email text NOT NULL,
    "emailVerified" timestamp(3) without time zone,
    image text,
    "passwordHash" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    phone text
);


--
-- Name: VerificationToken; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."VerificationToken" (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: Account; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Account" (id, "userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM stdin;
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditLog" (id, action, ip, "userId", metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: LoginChallenge; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."LoginChallenge" (id, "userId", mode, "codeHash", "codeExpiresAt", "codeAttempts", "verifiedAt", "loginTokenHash", "loginTokenExpiresAt", "loginTokenUsedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PasswordResetChallenge; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PasswordResetChallenge" (id, "userId", "emailCodeHash", "emailCodeVerifiedAt", "emailCodeExpiresAt", "emailCodeAttempts", "smsCodeHash", "smsCodeVerifiedAt", "smsCodeExpiresAt", "smsCodeAttempts", "resetTokenHash", "resetTokenExpiresAt", "resetTokenUsedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PasswordResetToken; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PasswordResetToken" (id, "userId", "tokenHash", "expiresAt", "usedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: RateLimitAttempt; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RateLimitAttempt" (id, key, "createdAt") FROM stdin;
cmm7eb0280000lul4lon86zyh	login-email-start:127.0.0.1	2026-03-01 06:55:12.657
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Session" (id, "sessionToken", "userId", expires) FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, name, email, "emailVerified", image, "passwordHash", "createdAt", "updatedAt", phone) FROM stdin;
\.


--
-- Data for Name: VerificationToken; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."VerificationToken" (identifier, token, expires) FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
a3561b61-47c6-4dc1-9f5d-c8d29a5edf0f	85b36cf83273f1b695f44ae97b82d8c1d0079af09b78cbfc584d8ed77cd39168	2026-03-01 09:44:16.237088+03	20260227_auth_init	\N	\N	2026-03-01 09:44:16.223027+03	1
1376b37d-99b8-4066-b384-75c877a97068	581f149fca2e7f47b762b68bdb5b806b9b07f067f3b9677b73baea228c870c26	2026-03-01 09:44:16.244612+03	20260228_add_login_challenges	\N	\N	2026-03-01 09:44:16.237907+03	1
2956785b-0c48-42f5-b448-809e903e3c9e	6ed233e5e040b8579874ae01e232864ca8e3de5c78831038617dbe7774907e59	2026-03-01 09:44:16.25108+03	20260228_add_password_reset_challenges	\N	\N	2026-03-01 09:44:16.245376+03	1
43f024c2-ecc0-4dd0-b2a4-adffccf8a525	d27416a8b06a08ab9002523b4964062e86fa8b8d10965122dddc34ca8d3d26dd	2026-03-01 09:44:16.257758+03	20260228_add_password_reset_tokens	\N	\N	2026-03-01 09:44:16.251805+03	1
f9cb65b5-0678-4cc2-8bf9-4ca8f4287d28	b21b023fe80fa268d1fb10d553544960dd26342b12b0a3d2f150208fd4d01152	2026-03-01 09:44:16.261593+03	20260228_add_user_phone	\N	\N	2026-03-01 09:44:16.258516+03	1
f131154c-4dc9-4ac0-9b58-18d99bb10ad4	1ac4bd93691fad554007ce050df53a1e6d36e744f735060481c1d3cf8d2f6e56	2026-03-01 09:44:16.266344+03	20260228180747_add_rate_limit_attempt	\N	\N	2026-03-01 09:44:16.262557+03	1
2987ff3e-9bca-4b99-a9e0-010a947ff5eb	b906ccb1bb6a8ff779e648242d1244fb0faebaf965b7febc789049e26c647885	2026-03-01 09:44:16.271214+03	20260228182506_add_audit_log	\N	\N	2026-03-01 09:44:16.267073+03	1
\.


--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: LoginChallenge LoginChallenge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LoginChallenge"
    ADD CONSTRAINT "LoginChallenge_pkey" PRIMARY KEY (id);


--
-- Name: PasswordResetChallenge PasswordResetChallenge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PasswordResetChallenge"
    ADD CONSTRAINT "PasswordResetChallenge_pkey" PRIMARY KEY (id);


--
-- Name: PasswordResetToken PasswordResetToken_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY (id);


--
-- Name: RateLimitAttempt RateLimitAttempt_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RateLimitAttempt"
    ADD CONSTRAINT "RateLimitAttempt_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Account_provider_providerAccountId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Account_provider_providerAccountId_key" ON public."Account" USING btree (provider, "providerAccountId");


--
-- Name: Account_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Account_userId_idx" ON public."Account" USING btree ("userId");


--
-- Name: AuditLog_action_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_action_createdAt_idx" ON public."AuditLog" USING btree (action, "createdAt");


--
-- Name: AuditLog_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_createdAt_idx" ON public."AuditLog" USING btree ("createdAt");


--
-- Name: AuditLog_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_userId_createdAt_idx" ON public."AuditLog" USING btree ("userId", "createdAt");


--
-- Name: LoginChallenge_codeExpiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "LoginChallenge_codeExpiresAt_idx" ON public."LoginChallenge" USING btree ("codeExpiresAt");


--
-- Name: LoginChallenge_loginTokenExpiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "LoginChallenge_loginTokenExpiresAt_idx" ON public."LoginChallenge" USING btree ("loginTokenExpiresAt");


--
-- Name: LoginChallenge_mode_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "LoginChallenge_mode_idx" ON public."LoginChallenge" USING btree (mode);


--
-- Name: LoginChallenge_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "LoginChallenge_userId_idx" ON public."LoginChallenge" USING btree ("userId");


--
-- Name: PasswordResetChallenge_emailCodeExpiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PasswordResetChallenge_emailCodeExpiresAt_idx" ON public."PasswordResetChallenge" USING btree ("emailCodeExpiresAt");


--
-- Name: PasswordResetChallenge_resetTokenExpiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PasswordResetChallenge_resetTokenExpiresAt_idx" ON public."PasswordResetChallenge" USING btree ("resetTokenExpiresAt");


--
-- Name: PasswordResetChallenge_smsCodeExpiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PasswordResetChallenge_smsCodeExpiresAt_idx" ON public."PasswordResetChallenge" USING btree ("smsCodeExpiresAt");


--
-- Name: PasswordResetChallenge_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PasswordResetChallenge_userId_idx" ON public."PasswordResetChallenge" USING btree ("userId");


--
-- Name: PasswordResetToken_expiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PasswordResetToken_expiresAt_idx" ON public."PasswordResetToken" USING btree ("expiresAt");


--
-- Name: PasswordResetToken_tokenHash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PasswordResetToken_tokenHash_key" ON public."PasswordResetToken" USING btree ("tokenHash");


--
-- Name: PasswordResetToken_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PasswordResetToken_userId_idx" ON public."PasswordResetToken" USING btree ("userId");


--
-- Name: RateLimitAttempt_key_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "RateLimitAttempt_key_createdAt_idx" ON public."RateLimitAttempt" USING btree (key, "createdAt");


--
-- Name: Session_sessionToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Session_sessionToken_key" ON public."Session" USING btree ("sessionToken");


--
-- Name: Session_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Session_userId_idx" ON public."Session" USING btree ("userId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_phone_key" ON public."User" USING btree (phone);


--
-- Name: VerificationToken_identifier_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "VerificationToken_identifier_token_key" ON public."VerificationToken" USING btree (identifier, token);


--
-- Name: VerificationToken_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "VerificationToken_token_key" ON public."VerificationToken" USING btree (token);


--
-- Name: Account Account_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: LoginChallenge LoginChallenge_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LoginChallenge"
    ADD CONSTRAINT "LoginChallenge_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PasswordResetChallenge PasswordResetChallenge_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PasswordResetChallenge"
    ADD CONSTRAINT "PasswordResetChallenge_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PasswordResetToken PasswordResetToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict oqHpw6RPnmb0bGwOJfYockcnouBd6OXAJk9QAkq8mhWULQKFhqf0ov7ETmiY4ta

